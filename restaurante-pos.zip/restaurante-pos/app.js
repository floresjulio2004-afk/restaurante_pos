const express = require('express');
const { MongoClient } = require('mongodb');
const app = express();
const port = 3000;

const url = 'mongodb://localhost:27017';
const client = new MongoClient(url);
let db, usuariosCollection, pedidosCollection;

app.use(express.json());
app.use(express.static('public'));

async function registrarUsuarioEnBD(nombre, usuario, password) {
    const existe = await usuariosCollection.findOne({ usuario });
    if (existe) return null;
    return await usuariosCollection.insertOne({ nombre, usuario, password });
}

app.post('/api/registrar', async (req, res) => {
    const { nombre, usuario, password } = req.body;
    const resultado = await registrarUsuarioEnBD(nombre, usuario, password);
    if (resultado) {
        res.status(200).json({ exito: true, mensaje: '¡Usuario creado con éxito!' });
    } else {
        res.status(400).json({ exito: false, mensaje: 'El usuario ya existe' });
    }
});

app.post('/api/login', async (req, res) => {
    const { usuario, password } = req.body;
    const cuenta = await usuariosCollection.findOne({ usuario, password });
    if (cuenta) {
        res.status(200).json({ exito: true, nombre: cuenta.nombre });
    } else {
        res.status(401).json({ exito: false, mensaje: 'Credenciales inválidas' });
    }
});

app.post('/api/nuevo-pedido', async (req, res) => {
    const { usuario, plato, precio } = req.body;
    await pedidosCollection.insertOne({ usuario, plato, precio: parseFloat(precio), facturado: false });
    res.status(200).json({ mensaje: `${plato} agregado.` });
});

app.post('/api/factura', async (req, res) => {
    const { usuario, nombreCliente } = req.body;
    const items = await pedidosCollection.find({ usuario, facturado: false }).toArray();
    if (items.length === 0) return res.status(400).json({ mensaje: 'Carrito vacío' });

    let subtotal = 0;
    items.forEach(i => subtotal += i.precio);
    const iva = subtotal * 0.15;
    const total = subtotal + iva;

    await pedidosCollection.updateMany({ usuario, facturado: false }, { $set: { facturado: true } });

    res.status(200).json({
        cliente: nombreCliente,
        fecha: new Date().toLocaleString(),
        items,
        subtotal: subtotal.toFixed(2),
        iva: iva.toFixed(2),
        total: total.toFixed(2)
    });
});

async function iniciar() {
    await client.connect();
    db = client.db('mydatabase');
    usuariosCollection = db.collection('usuarios');
    pedidosCollection = db.collection('pedidos');
    app.listen(port, () => console.log('Servidor activo en puerto 3000'));
}
iniciar().catch(console.error);